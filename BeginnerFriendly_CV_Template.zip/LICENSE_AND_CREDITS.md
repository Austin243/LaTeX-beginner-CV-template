# License and Credits

## Author

Austin Ellis

## Links

- Website: https://austinellis.org
- LinkedIn: https://www.linkedin.com/in/austin243/

## License

This project is licensed under the MIT License. See `LICENSE`.
